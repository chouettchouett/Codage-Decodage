#ifndef DH_GEN_GROUP_TEST_H
#define DH_GEN_GROUP_TEST_H

// Fonction pour tester l'option -o avec un nom de fichier valide
void test_option_o();

// Fonction pour tester l'option -o sans nom de fichier
void test_option_o_no_filename();

// Fonction pour tester l'option -h
void test_option_h();

#endif // DH_GEN_GROUP_TEST_H
