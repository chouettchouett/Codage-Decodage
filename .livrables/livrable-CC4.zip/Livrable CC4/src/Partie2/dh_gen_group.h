#ifndef DH_GEN_GROUP_H
#define DH_GEN_GROUP_H

void dh_gen_group(char *file_name);

#endif