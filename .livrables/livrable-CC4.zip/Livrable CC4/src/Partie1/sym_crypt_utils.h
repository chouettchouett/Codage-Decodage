#ifndef __SYM_CRYPT_UTLS__
#define __SYM_CRYPT_UTLS__

void set_config(char* key_path, char* input_path, char* output_path);

void get_config(char* key_path, char* input_path, char* output_path);
 
#endif